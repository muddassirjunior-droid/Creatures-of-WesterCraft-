package net.westercraft.dragons;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/**
 * Every item the mod adds gets registered here, in one place.
 * This is the standard Fabric pattern: one static final field per item,
 * built through a small helper so registration is never forgotten.
 */
public class ModItems {

	// Milestone 1 item: a plain item for now (no special right-click
	// behavior yet -- that's a later milestone once you're comfortable
	// with the basics). maxCount(1) means it won't stack, which fits an
	// item meant to represent a single personal seal.
	public static final Item WAX_SEAL_STAMP = registerItem(
			"wax_seal_stamp",
			new Item(new Item.Settings().maxCount(1))
	);

	/**
	 * Registers one item under this mod's namespace and returns it.
	 * "westercraft_dragons:wax_seal_stamp" is the full ID Minecraft
	 * will know this item by internally.
	 */
	private static Item registerItem(String name, Item item) {
		return Registry.register(
				Registries.ITEM,
				new Identifier(WestercraftDragons.MOD_ID, name),
				item
		);
	}

	/**
	 * Called once from WestercraftDragons.onInitialize(). Doesn't need to
	 * do anything itself -- just referencing this class is enough to run
	 * the static field initializers above, which is what actually
	 * registers the items. This method exists so the initialization
	 * order is explicit and logged, rather than happening "by accident."
	 */
	public static void registerModItems() {
		WestercraftDragons.LOGGER.info("Registering items for " + WestercraftDragons.MOD_ID);
	}
}
