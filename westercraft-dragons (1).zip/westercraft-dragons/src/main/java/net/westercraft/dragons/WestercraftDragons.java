package net.westercraft.dragons;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ItemGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Milestone 1: this class is the mod's entrypoint. Fabric Loader reads
 * fabric.mod.json, sees this class listed under "entrypoints" -> "main",
 * and calls onInitialize() once, right as the game is starting up.
 *
 * Everything the mod does starts from here -- right now that's just
 * registering one item, but this is also where future systems
 * (entities, the dragon species loader, etc.) will get switched on.
 */
public class WestercraftDragons implements ModInitializer {

	// The mod ID. Must match the "id" field in fabric.mod.json exactly.
	// Used as the namespace for every item/block/entity we register,
	// e.g. "westercraft_dragons:wax_seal_stamp".
	public static final String MOD_ID = "westercraft_dragons";

	// A logger so we can print messages to the game's log file instead of
	// using System.out.println (this is the convention every Fabric mod uses).
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("[Westercraft Dragons] Initializing...");

		// Registers all our items (see ModItems.java)
		ModItems.registerModItems();

		// Adds our items to an existing vanilla creative-mode tab (Tools)
		// so they actually show up somewhere in the creative inventory.
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
			entries.add(ModItems.WAX_SEAL_STAMP);
		});

		LOGGER.info("[Westercraft Dragons] Done. Registered items: {}", ModItems.WAX_SEAL_STAMP);
	}
}
