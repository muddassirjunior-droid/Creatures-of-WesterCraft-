# Westercraft Dragons

Milestone 1 of the dragon mod plan: a real, working Fabric mod project
for Minecraft 1.20.1, with one item (Wax Seal Stamp) fully registered,
textured, and named -- proving the whole pipeline works before we touch
anything as complex as an animated flying entity.

## What's already done for you
- Full Gradle project (wrapper, build.gradle, gradle.properties) targeting
  **Minecraft 1.20.1**, **Yarn 1.20.1+build.10**, **Fabric Loader 0.15.11**,
  **Fabric API 0.91.1+1.20.1** -- all real, verified version numbers.
- **GeckoLib 4.4.9** already wired into build.gradle (repo + dependency),
  ready for when we build the animated dragon later. You don't need to
  touch build.gradle again for that.
- One working item: `westercraft_dragons:wax_seal_stamp`, with its Java
  registration, item model, 16x16 texture, lang entry, and mod icon.

## What YOU need to do (this can't happen on my end -- it's your machine)

This project is set up for **VS Code**. (A Gradle project doesn't actually
care which editor opens it -- there's just extra `.vscode/` config in here
so VS Code gets one-click tasks instead of you typing terminal commands.)

1. **Install Java 17** if you haven't: https://adoptium.net (get the JDK,
   Temurin build). After installing, confirm it worked by opening a
   terminal and running `java -version` -- it should print `17.x.x`.
2. **Install VS Code** if you haven't: https://code.visualstudio.com
3. **Open this folder** in VS Code: File -> Open Folder -> select the
   `westercraft-dragons` folder itself (not a file inside it).
4. VS Code will pop a notification recommending extensions (from
   `.vscode/extensions.json`) -- click **Install All**. This installs:
   - **Extension Pack for Java** (`vscjava.vscode-java-pack`) -- Java
     language support, debugger, and now bundles Gradle support too
   - **Gradle for Java** (`vscjava.vscode-gradle`) -- explicit Gradle
     task view, installed separately just to be safe
5. Once installed, VS Code will start importing the Gradle project
   automatically (watch the bottom status bar -- it'll say "Java:
   Loading..." or similar). **First import takes 10-20 minutes**, same
   as any IDE, because it's downloading and decompiling Minecraft
   itself. Let it finish before doing anything else.
6. **Run the client** one of these ways:
   - Press `Ctrl+Shift+B` (`Cmd+Shift+B` on Mac) -- runs the default
     build task, which is set to **Run Minecraft Client**
   - Or: Terminal menu -> Run Task... -> **Run Minecraft Client**
   - Or: open the Gradle side panel (elephant icon in the left sidebar)
     -> westercraft-dragons -> Tasks -> fabric -> double-click `runClient`
   - Or just type it directly in VS Code's integrated terminal:
     `./gradlew runClient` (Mac/Linux) or `gradlew.bat runClient` (Windows)
7. A vanilla-looking Minecraft window should open. In-game: open a
   creative world, go to the **Tools** tab in the creative inventory,
   and look for **"Wax Seal Stamp"** near the end. If it's there with
   its icon showing, everything works end to end.

**One extra step VS Code needs that IntelliJ does automatically:** for
proper autocomplete and "jump to definition" on Minecraft's own classes,
run the **Generate Minecraft Sources** task once (Terminal -> Run Task...
-> Generate Minecraft Sources). Not required to compile or run the mod --
only makes editing nicer.

### If something goes wrong
- **Java extension stuck on "Loading..." forever**: Command Palette
  (`Ctrl+Shift+P`) -> "Java: Clean Java Language Server Workspace" ->
  reload. Fixes most stuck-import issues.
- **Gradle tasks panel is empty**: make sure the Gradle for Java
  extension finished installing, then Command Palette -> "Gradle: Refresh
  Gradle Projects".
- **"Could not resolve dependency" for yarn/loader/fabric-api/geckolib**:
  one of the pinned versions in `gradle.properties` may have been pulled
  from Maven since this was written. Check https://fabricmc.net/develop
  (pick Minecraft 1.20.1) for current values, and
  https://modrinth.com/mod/geckolib/versions?g=1.20.1&l=fabric for
  GeckoLib, then update `gradle.properties` accordingly.
- **Item shows as a missing-texture purple/black cube instead of the
  seal icon**: usually a resource pack caching issue -- press F3+T
  in-game to reload resources, or fully restart the client task.
- **`./gradlew: Permission denied` on Mac/Linux**: run
  `chmod +x gradlew` once in the terminal, then try again.

## Project layout, for orientation
```
src/main/java/net/westercraft/dragons/
    WestercraftDragons.java   <- mod entrypoint, called once on startup
    ModItems.java             <- all item registrations live here

src/main/resources/
    fabric.mod.json           <- mod metadata Fabric Loader reads
    assets/westercraft_dragons/
        icon.png               <- mod icon
        lang/en_us.json         <- display names
        models/item/...         <- how items render
        textures/item/...       <- the actual pixel art
```

## Where this goes next (already planned, will build in future sessions)
1. A custom block (same registry pattern, one more layer)
2. A simple non-animated custom entity + AI goals
3. A GeckoLib-animated entity (the real prerequisite skill for the dragon)
4. The dragon itself: flight AI, fire breath, taming, growth stages
5. The data-driven `dragon_species` JSON system so Vhagar, Caraxes,
   Balerion, etc. can be added later as data, not code
